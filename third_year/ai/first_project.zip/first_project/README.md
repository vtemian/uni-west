Implement simple A* for the Romania cities problem
