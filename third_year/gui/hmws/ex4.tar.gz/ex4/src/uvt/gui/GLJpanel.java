package uvt.gui;

import com.jogamp.opengl.awt.GLJPanel;

/**
 * Created by w on 25.05.2016.
 */
public class GLJpanel extends GLJPanel {
    public GLJpanel(Object p0) {
    }
}
