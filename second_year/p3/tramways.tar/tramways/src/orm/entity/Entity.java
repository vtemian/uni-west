package orm.entity;

public abstract class Entity implements IEntity {}
