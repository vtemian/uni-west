package orm.entity;

public interface IEntity {}
