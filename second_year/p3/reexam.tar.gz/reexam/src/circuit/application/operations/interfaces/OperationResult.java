package circuit.application.operations.interfaces;

public interface OperationResult {

}
