package circuit.application.devices.output;

public interface OutputDevice {
    public void print(String print);
}
