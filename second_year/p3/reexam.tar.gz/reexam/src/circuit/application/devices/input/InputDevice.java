package circuit.application.devices.input;

public interface InputDevice {
    public String getCSVFilepath();
}
