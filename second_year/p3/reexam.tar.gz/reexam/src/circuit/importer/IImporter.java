package circuit.importer;

public interface IImporter {
    public void importOperations();
}
