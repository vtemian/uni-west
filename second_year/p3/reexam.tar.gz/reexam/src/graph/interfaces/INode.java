package graph.interfaces;

public interface INode {
    public String getName();
}
