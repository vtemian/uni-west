package graph.exceptions;

public class NullNodeException extends Exception{
}
