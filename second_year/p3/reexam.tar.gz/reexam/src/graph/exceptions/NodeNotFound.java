package graph.exceptions;

public class NodeNotFound extends Exception{
}
