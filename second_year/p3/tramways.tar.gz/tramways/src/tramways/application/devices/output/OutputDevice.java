package tramways.application.devices.output;

import java.util.ArrayList;
import tramways.application.Node;

public interface OutputDevice {
    public void showRoute(ArrayList<Node> route);
}
