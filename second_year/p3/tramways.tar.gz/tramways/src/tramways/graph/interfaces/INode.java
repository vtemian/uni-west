package tramways.graph.interfaces;

public interface INode {
    public String getName();
}
