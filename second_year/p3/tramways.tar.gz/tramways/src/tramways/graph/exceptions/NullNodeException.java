package tramways.graph.exceptions;

public class NullNodeException extends Exception{
}
