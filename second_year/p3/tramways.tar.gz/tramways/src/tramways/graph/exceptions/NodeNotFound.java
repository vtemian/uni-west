package tramways.graph.exceptions;

public class NodeNotFound extends Exception{
}
