#ifndef ERRORS
#define ERRORS

void term_error();
void file_error(char* filename);

#endif
