#define BACKSPACE 127
#define ENTER '\n'
#define ARROW_UP 65
#define ARROW_DOWN 66
