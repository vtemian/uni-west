another shell
=============

Yeah....because bash and zsh are to mainstream!

### mvp
  * can read a command
  * can write a command on screen
  * add command to history
  * press up    -> go foward in history
  * press down  -> go backward in history
  * press CTRL+R -> do a reverse search
  * can execute a command
  * knows pipes
